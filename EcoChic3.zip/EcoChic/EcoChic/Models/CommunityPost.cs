﻿using System.ComponentModel.DataAnnotations;
using System.ComponentModel.DataAnnotations.Schema;

namespace EcoChic.Models
{
    public class CommunityPost
    {
        [Key]
        public int PostID { get; set; }

        public int UserID { get; set; }

        [Display(Name = "Post Content")]
        public string PostContent { get; set; }

        [Display(Name = "Post Date")]
        [DataType(DataType.DateTime)]
        public DateTime PostDate { get; set; }

        public int Likes { get; set; }

        public int Comments { get; set; }

        [Display(Name = "Suggested By")]
        public string SuggestedBy { get; set; }

        public string Description { get; set; }

        [Display(Name = "Date Suggested")]
        [DataType(DataType.DateTime)]
        public DateTime DateSuggested { get; set; }
    }
}
