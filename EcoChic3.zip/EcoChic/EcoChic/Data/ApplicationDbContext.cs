﻿using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using EcoChic.Models;

namespace EcoChic.Data
{
    public class ApplicationDbContext : IdentityDbContext
    {
        public ApplicationDbContext(DbContextOptions<ApplicationDbContext> options)
            : base(options)
        {
        }
        public DbSet<EcoChic.Models.AppUser> AppUser { get; set; } = default!;
        public DbSet<EcoChic.Models.CommunityPost> CommunityPost { get; set; } = default!;
        public DbSet<EcoChic.Models.Payment> Payment { get; set; } = default!;
        public DbSet<EcoChic.Models.WardrobeItem> WardrobeItem { get; set; } = default!;
    }
}
