﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;

namespace EcoChic.Pages.CommunityPosts
{
    public class EditModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public EditModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
        public CommunityPost CommunityPost { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.CommunityPost == null)
            {
                return NotFound();
            }

            var communitypost =  await _context.CommunityPost.FirstOrDefaultAsync(m => m.PostID == id);
            if (communitypost == null)
            {
                return NotFound();
            }
            CommunityPost = communitypost;
            return Page();
        }

        // To protect from overposting attacks, enable the specific properties you want to bind to.
        // For more details, see https://aka.ms/RazorPagesCRUD.
        public async Task<IActionResult> OnPostAsync()
        {
            if (!ModelState.IsValid)
            {
                return Page();
            }

            _context.Attach(CommunityPost).State = EntityState.Modified;

            try
            {
                await _context.SaveChangesAsync();
            }
            catch (DbUpdateConcurrencyException)
            {
                if (!CommunityPostExists(CommunityPost.PostID))
                {
                    return NotFound();
                }
                else
                {
                    throw;
                }
            }

            return RedirectToPage("./Index");
        }

        private bool CommunityPostExists(int id)
        {
          return (_context.CommunityPost?.Any(e => e.PostID == id)).GetValueOrDefault();
        }
    }
}
