﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;

namespace EcoChic.Pages.WardrobeItems
{
    public class DetailsModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public DetailsModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

      public WardrobeItem WardrobeItem { get; set; } = default!; 

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.WardrobeItem == null)
            {
                return NotFound();
            }

            var wardrobeitem = await _context.WardrobeItem.FirstOrDefaultAsync(m => m.ItemID == id);
            if (wardrobeitem == null)
            {
                return NotFound();
            }
            else 
            {
                WardrobeItem = wardrobeitem;
            }
            return Page();
        }
    }
}
