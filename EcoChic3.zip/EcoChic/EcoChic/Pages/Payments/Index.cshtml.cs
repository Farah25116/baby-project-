﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EcoChic.Pages.Payments
{
    public class IndexModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public IndexModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<Payment> Payment { get;set; } = default!;
        public SelectList Methods { get; set; } = default!;

        [BindProperty(SupportsGet = true)]
        public string? PaymentMethod { get; set; }

        public async Task OnGetAsync()
        {
            var methodQuery = _context.Payment.OrderBy(p => p.PaymentMethod).Select(p => p.PaymentMethod);
            var payments = from p in _context.Payment select p;

            if (!string.IsNullOrEmpty(PaymentMethod))
            {
                payments = payments.Where(p => p.PaymentMethod == PaymentMethod);
            }

            Methods = new SelectList(await methodQuery.Distinct().ToListAsync());
            Payment = await payments.ToListAsync();
        }
    }
}

