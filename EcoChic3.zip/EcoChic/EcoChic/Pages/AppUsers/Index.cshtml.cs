﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EcoChic.Pages.AppUsers
{
    public class IndexModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public IndexModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<AppUser> AppUser { get; set; } = default!;
        [BindProperty(SupportsGet = true)]
        public string? UserName { get; set; }

        public SelectList SubscriptionType { get; set; } = default!;

        [BindProperty(SupportsGet = true)]
        public string? SubscriptionTypes { get; set; }

        public async Task OnGetAsync()
        {
            IQueryable<string> typeQuery = from u in _context.AppUser
                                           orderby u.SubscriptionType
                                           select u.SubscriptionType;

            var AppUsers = from u in _context.AppUser
                        select u;

            if (!string.IsNullOrEmpty(UserName))
            {
                AppUsers = AppUsers.Where(u => u.Name.Contains(UserName));
            }

            if (!string.IsNullOrEmpty(SubscriptionTypes))
            {
                AppUsers = AppUsers.Where(u => u.SubscriptionType == SubscriptionTypes);
            }

            SubscriptionType = new SelectList(await typeQuery.Distinct().ToListAsync());
            AppUser = await AppUsers.ToListAsync();
        }
    }

}

