﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.AspNetCore.Mvc.Rendering;
using EcoChic.Data;
using EcoChic.Models;

namespace EcoChic.Pages.WardrobeItems
{
    public class CreateModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public CreateModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IActionResult OnGet()
        {
            return Page();
        }

        [BindProperty]
        public WardrobeItem WardrobeItem { get; set; } = default!;
        

        // To protect from overposting attacks, see https://aka.ms/RazorPagesCRUD
        public async Task<IActionResult> OnPostAsync()
        {
          if (!ModelState.IsValid || _context.WardrobeItem == null || WardrobeItem == null)
            {
                return Page();
            }

            _context.WardrobeItem.Add(WardrobeItem);
            await _context.SaveChangesAsync();

            return RedirectToPage("./Index");
        }
    }
}
