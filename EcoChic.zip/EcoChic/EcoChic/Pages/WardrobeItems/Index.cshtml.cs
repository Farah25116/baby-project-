﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;
using Microsoft.AspNetCore.Mvc.Rendering;

namespace EcoChic.Pages.WardrobeItems
{
    public class IndexModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public IndexModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<WardrobeItem> WardrobeItem { get;set; } = default!;
        public SelectList Categories { get; set; } = default!;

        [BindProperty(SupportsGet = true)]
        public string? ItemName { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? Category { get; set; }

        public async Task OnGetAsync()
        {
            var categoryQuery = _context.WardrobeItem.OrderBy(i => i.Category).Select(i => i.Category);
            var items = from i in _context.WardrobeItem select i;

            if (!string.IsNullOrEmpty(ItemName))
            {
                items = items.Where(i => i.ItemName.Contains(ItemName));
            }

            if (!string.IsNullOrEmpty(Category))
            {
                items = items.Where(i => i.Category == Category);
            }

            Categories = new SelectList(await categoryQuery.Distinct().ToListAsync());
            WardrobeItem = await items.ToListAsync();
        }
    }
}

