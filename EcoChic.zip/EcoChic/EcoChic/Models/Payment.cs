﻿using System.ComponentModel.DataAnnotations;

namespace EcoChic.Models
{
    public class Payment
    {
        [Key]
        public int PaymentID { get; set; }

        public int UserID { get; set; }

        [Display(Name = "Payment Date")]
        [DataType(DataType.Date)]
        public DateTime PaymentDate { get; set; }

        public decimal Amount { get; set; }

        [Display(Name = "Payment Method")]
        public string PaymentMethod { get; set; }
    }

}
