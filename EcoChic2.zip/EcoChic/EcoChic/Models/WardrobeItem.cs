﻿using System.ComponentModel.DataAnnotations;

namespace EcoChic.Models
{
    public class WardrobeItem
    {
        [Key]
        public int ItemID { get; set; }

        public int UserID { get; set; }

        [Display(Name = "Item Name")]
        public string ItemName { get; set; }

        public string Category { get; set; }

        [Display(Name = "Upload Date")]
        [DataType(DataType.Date)]
        public DateTime UploadDate { get; set; }

        [Display(Name = "Image URL")]
        public string ImageURL { get; set; }

        public string Color { get; set; }

        public string Material { get; set; }
    }

}
