﻿using Microsoft.EntityFrameworkCore;
using EcoChic.Data;

namespace EcoChic.Models
{
    public static class SeedData
    {
        public static void Initialize(IServiceProvider serviceProvider)
        {
            using (var context = new Data.ApplicationDbContext(
            serviceProvider.GetRequiredService<
            DbContextOptions<Data.ApplicationDbContext>>()))

            {
                if (context == null)
                {
                    throw new ArgumentNullException("Null EcoChicDbContext");
                }

                // Check if Users already exist
                if (context.AppUser.Any())
                {
                    return; // DB has been seeded
                }
                // Seed Users
                context.AppUser.AddRange(
                    new AppUser
                    {
                        Name = "Alice Johnson",
                        Email = "alice@example.com",
                        SubscriptionType = "Premium",
                        DateJoined = DateTime.Parse("2023-01-15"),
                        ProfilePicture = "https://example.com/alice.jpg",
                        Location = "Vancouver"
                    },
                    new AppUser
                    {
                        Name = "Bob Smith",
                        Email = "bob@example.com",
                        SubscriptionType = "Free",
                        DateJoined = DateTime.Parse("2022-11-05"),
                        ProfilePicture = "https://example.com/bob.jpg",
                        Location = "Vancouver"
                    },
                    new AppUser
                    {
                        Name = "Tim Slater",
                        Email = "Tim@example.com",
                        SubscriptionType = "Free",
                        DateJoined = DateTime.Parse("2022-11-06"),
                        ProfilePicture = "https://example.com/Tim.jpg",
                        Location = "Vancouver"
                    },
                    new AppUser
                    {
                        Name = "Maya Baker ",
                        Email = "Maya@example.com",
                        SubscriptionType = "Premium",
                        DateJoined = DateTime.Parse("2022-12-05"),
                        ProfilePicture = "https://example.com/Maya.jpg",
                        Location = "Vancouver"
                    }
                );
                context.SaveChanges();

                // Seed Community Posts

                {
                    if (context == null)
                    {
                        throw new ArgumentNullException("Null EcoChicDbContext");
                    }

                    // Check if CommunityPost already exist
                    if (context.CommunityPost.Any())
                    {
                        return; // DB has been seeded
                    }

                    context.CommunityPost.AddRange(
                        new CommunityPost
                        {
                            PostContent = "Excited to share my sustainable fashion tips!",
                            PostDate = DateTime.Parse("2024-03-10"),
                            Likes = 15,
                            Comments = 2,
                            SuggestedBy = "Alice",
                            Description = "Discussing eco-friendly fabrics.",
                            DateSuggested = DateTime.Parse("2024-03-05")
                        },
                        new CommunityPost
                        {
                            PostContent = "Check out my upcycled clothing ideas!",
                            PostDate = DateTime.Parse("2024-03-12"),
                            Likes = 25,
                            Comments = 5,
                            SuggestedBy = "Bob",
                            Description = "Reusing old clothes for new styles.",
                            DateSuggested = DateTime.Parse("2024-03-08")
                        },
                        new CommunityPost
                        {
                            PostContent = "New sustainable fashion trends in 2024!",
                            PostDate = DateTime.Parse("2024-03-15"),
                            Likes = 30,
                            Comments = 7,
                            SuggestedBy = "Alice",
                            Description = "Analyzing the latest eco-friendly fashion brands.",
                            DateSuggested = DateTime.Parse("2024-03-14")
                        },
                        new CommunityPost
                        {
                            PostContent = "DIY guide for repurposing old jeans!",
                            PostDate = DateTime.Parse("2024-03-18"),
                            Likes = 40,
                            Comments = 10,
                            SuggestedBy = "Bob",
                            Description = "Step-by-step guide for transforming old jeans into new styles.",
                            DateSuggested = DateTime.Parse("2024-03-16")
                        }
                    );

                    context.SaveChanges();

                    // Seed Payments

                    {
                        if (context == null)
                        {
                            throw new ArgumentNullException("Null EcoChicDbContext");
                        }

                        // Check if Payment already exist
                        if (context.Payment.Any())
                        {
                            return; // DB has been seeded
                        }
                        context.Payment.AddRange(
                            new Payment
                            {
                                PaymentDate = DateTime.Parse("2024-02-01"),
                                Amount = 9.99M,
                                PaymentMethod = "Credit Card"
                            },
                            new Payment
                            {
                                PaymentDate = DateTime.Parse("2024-02-05"),
                                Amount = 14.99M,
                                PaymentMethod = "PayPal"
                            },
                            new Payment
                            {
                                PaymentDate = DateTime.Parse("2024-02-10"),
                                Amount = 19.99M,
                                PaymentMethod = "Debit Card"
                            },
                            new Payment
                            {
                                PaymentDate = DateTime.Parse("2024-02-20"),
                                Amount = 24.99M,
                                PaymentMethod = "PayPal"
                            }
                        );

                        context.SaveChanges();

                        // Seed Wardrobe Items

                        {
                            if (context == null)
                            {
                                throw new ArgumentNullException("Null EcoChicDbContext");
                            }

                            // Check if WardrobeItem already exist
                            if (context.WardrobeItem.Any())
                            {
                                return; // DB has been seeded
                            }
                            context.WardrobeItem.AddRange(
                                new WardrobeItem
                                {
                                    ItemName = "Vintage Denim Jacket",
                                    Category = "Jackets",
                                    UploadDate = DateTime.Parse("2024-03-01"),
                                    ImageURL = "https://example.com/denim.jpg",
                                    Color = "Blue",
                                    Material = "Cotton"
                                },
                                new WardrobeItem
                                {
                                    ItemName = "Organic Cotton T-Shirt",
                                    Category = "T-Shirts",
                                    UploadDate = DateTime.Parse("2024-03-05"),
                                    ImageURL = "https://example.com/tshirt.jpg",
                                    Color = "White",
                                    Material = "Organic Cotton"
                                },
                                new WardrobeItem
                                {
                                    ItemName = "Recycled Leather Bag",
                                    Category = "Accessories",
                                    UploadDate = DateTime.Parse("2024-03-07"),
                                    ImageURL = "https://example.com/bag.jpg",
                                    Color = "Brown",
                                    Material = "Recycled Leather"
                                },
                                new WardrobeItem
                                {
                                    ItemName = "Eco-Friendly Running Shoes",
                                    Category = "Footwear",
                                    UploadDate = DateTime.Parse("2024-03-10"),
                                    ImageURL = "https://example.com/shoes.jpg",
                                    Color = "Green",
                                    Material = "Recycled Plastic"
                                }
                            );

                            context.SaveChanges();
                        }
                    }
                }
            }
        }
    }
}




