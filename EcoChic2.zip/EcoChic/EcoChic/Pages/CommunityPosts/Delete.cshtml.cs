﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;

namespace EcoChic.Pages.CommunityPosts
{
    public class DeleteModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public DeleteModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        [BindProperty]
      public CommunityPost CommunityPost { get; set; } = default!;

        public async Task<IActionResult> OnGetAsync(int? id)
        {
            if (id == null || _context.CommunityPost == null)
            {
                return NotFound();
            }

            var communitypost = await _context.CommunityPost.FirstOrDefaultAsync(m => m.PostID == id);

            if (communitypost == null)
            {
                return NotFound();
            }
            else 
            {
                CommunityPost = communitypost;
            }
            return Page();
        }

        public async Task<IActionResult> OnPostAsync(int? id)
        {
            if (id == null || _context.CommunityPost == null)
            {
                return NotFound();
            }
            var communitypost = await _context.CommunityPost.FindAsync(id);

            if (communitypost != null)
            {
                CommunityPost = communitypost;
                _context.CommunityPost.Remove(CommunityPost);
                await _context.SaveChangesAsync();
            }

            return RedirectToPage("./Index");
        }
    }
}
