﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;
using Microsoft.EntityFrameworkCore;
using EcoChic.Data;
using EcoChic.Models;

namespace EcoChic.Pages.CommunityPosts
{
    public class IndexModel : PageModel
    {
        private readonly EcoChic.Data.ApplicationDbContext _context;

        public IndexModel(EcoChic.Data.ApplicationDbContext context)
        {
            _context = context;
        }

        public IList<CommunityPost> CommunityPost { get;set; } = default!;
        [BindProperty(SupportsGet = true)]
        public int? UserID { get; set; }

        [BindProperty(SupportsGet = true)]
        public string? SuggestedBy { get; set; }

        public async Task OnGetAsync()
        {
            var posts = from p in _context.CommunityPost
                        select p;

            if (UserID.HasValue)
            {
                posts = posts.Where(p => p.UserID == UserID.Value);
            }

            if (!string.IsNullOrEmpty(SuggestedBy))
            {
                posts = posts.Where(p => p.SuggestedBy.Contains(SuggestedBy));
            }

            CommunityPost = await posts.ToListAsync();
        }
    }
}
